import { useEffect, useState } from 'react';
import {
    Button, Input, makeStyles, Spinner, Text, tokens,
} from '@fluentui/react-components';
import type {
    GeneratedComponentProps, ReadableTableRow,
    nwind_orderdetails, nwind_orders, nwind_products, nwind_suppliers,
    ppcc_carrierattempt, ppcc_carrieroperation, ppcc_disruptioncase,
    ppcc_executionevidence, ppcc_impactedorder, ppcc_recoverydecision,
} from './RuntimeTypes';

type Case = ReadableTableRow<ppcc_disruptioncase>;
type Impact = ReadableTableRow<ppcc_impactedorder>;
type Decision = ReadableTableRow<ppcc_recoverydecision>;
type Operation = ReadableTableRow<ppcc_carrieroperation>;
type Attempt = ReadableTableRow<ppcc_carrierattempt>;
type Evidence = ReadableTableRow<ppcc_executionevidence>;
type SourceOrder = ReadableTableRow<nwind_orders>;
type SourceLine = ReadableTableRow<nwind_orderdetails>;
type SourceProduct = ReadableTableRow<nwind_products>;
type SourceSupplier = ReadableTableRow<nwind_suppliers>;
type PageProps = GeneratedComponentProps & { pageInput?: { recordId?: string; entityName?: string } };
type Result<T> = { rows: T[]; more: boolean };
type Detail = {
    impacts: Result<Impact>;
    decisions: Result<Decision>;
    operations: Result<Operation>;
    attempts: Result<Attempt>;
    evidence: Result<Evidence>;
    orders: Map<string, SourceOrder>;
    lines: Map<string, SourceLine>;
    product: SourceProduct | null;
    supplier: SourceSupplier | null;
};
type Load<T> = { value: T | null; loading: boolean; error: string | null; unauthorized: boolean; fetchedAt: number | null };
type Cached<T> = { value: T; fetchedAt: number };
type Store = {
    cases?: Cached<Result<Case>>;
    casesPending?: Promise<Cached<Result<Case>>>;
    details: Map<string, Cached<Detail>>;
    detailsPending: Map<string, Promise<Cached<Detail>>>;
};

const CACHE_KEY = '__ppControlTowerHome_v1';
const TTL = 60000;
const windowStore = window as unknown as Record<string, Store | undefined>;
const store = windowStore[CACHE_KEY] ?? (windowStore[CACHE_KEY] = { details: new Map(), detailsPending: new Map() });

const statusNames = ['New', 'Triaged', 'Impact assessed', 'Decision pending', 'Approved for execution', 'In execution', 'Resolved', 'Closed', 'Cancelled'];
const severityNames = ['Low', 'Medium', 'High', 'Critical'];
const actionNames = ['Split shipment', 'Expedite existing shipment', 'Alternate supplier', 'Substitute product', 'Backorder', 'Cancel order', 'No action'];
const approvalNames = ['Pending', 'Approved', 'Rejected', 'Cancelled', 'Expired'];
const operationNames = ['Draft', 'Pending approval', 'Ready', 'Submitted', 'In progress', 'Succeeded', 'Failed', 'Cancelled'];
const executionNames = ['Not started', 'Queued', 'In progress', 'Succeeded', 'Partially succeeded', 'Failed', 'Cancelled'];
const evidenceNames = ['Carrier response', 'Order update', 'Communication', 'System log', 'Manual verification'];
const operationTypes = ['Quote', 'Expedite', 'Reroute', 'Split shipment', 'Cancel'];

function choice(value: number | null | undefined, names: string[], start = 100000000): string {
    if (value == null) return 'Not recorded';
    return names[value - start] ?? `Unknown (${value})`;
}

function idOf(value: string | null | undefined): string | null {
    if (!value) return null;
    const match = value.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
    return match?.[0].toLowerCase() ?? null;
}

function date(value: Date | string | null | undefined): string {
    if (!value) return 'Not recorded';
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? 'Invalid date' : new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(parsed);
}

function amount(value: number | null | undefined): string {
    return value == null ? 'Not assessed' : new Intl.NumberFormat(undefined, { maximumFractionDigits: 2, minimumFractionDigits: 2 }).format(value);
}

function errorInfo(error: unknown): { message: string; unauthorized: boolean } {
    const typed = error as { status?: number; statusCode?: number; message?: string } | null;
    const unauthorized = typed?.status === 401 || typed?.status === 403 || typed?.statusCode === 401 || typed?.statusCode === 403 ||
        /\b(401|403|unauthorized|forbidden|access denied|privilege)\b/i.test(typed?.message ?? '');
    return {
        message: unauthorized ? 'Access denied. Your account cannot read one or more required records; contact an administrator.' :
            `Unable to load live data: ${typed?.message ?? 'An unexpected error occurred.'}`,
        unauthorized,
    };
}

function lookupName(row: object, field: string): string {
    const value = (row as Record<string, unknown>)[`${field}@OData.Community.Display.V1.FormattedValue`];
    return typeof value === 'string' && value ? value : 'Name unavailable';
}

const useStyles = makeStyles({
    root: {
        display: 'flex', flexDirection: 'column', gap: tokens.spacingVerticalL,
        padding: tokens.spacingHorizontalXL, boxSizing: 'border-box', width: '100%',
        color: tokens.colorNeutralForeground1, backgroundColor: tokens.colorNeutralBackground2,
        '@media (max-width: 600px)': { padding: tokens.spacingHorizontalM },
    },
    heading: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: tokens.spacingHorizontalM },
    controls: { display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: tokens.spacingHorizontalS },
    columns: { display: 'flex', flexWrap: 'wrap', gap: tokens.spacingHorizontalL, alignItems: 'flex-start' },
    sidebar: { flex: '1 1 17rem', minWidth: 0 },
    main: { flex: '3 1 32rem', minWidth: 0, display: 'flex', flexDirection: 'column', gap: tokens.spacingVerticalL },
    card: {
        backgroundColor: tokens.colorNeutralBackground1, borderRadius: tokens.borderRadiusMedium,
        padding: tokens.spacingHorizontalL, boxShadow: tokens.shadow2,
        display: 'flex', flexDirection: 'column', gap: tokens.spacingVerticalS, minWidth: 0,
    },
    list: { display: 'flex', flexDirection: 'column', gap: tokens.spacingVerticalS, maxHeight: '32rem', overflowY: 'auto' },
    mission: {
        display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: tokens.spacingVerticalXS,
        width: '100%', textAlign: 'left', padding: tokens.spacingHorizontalM,
        borderTopColor: tokens.colorNeutralStroke2, borderRightColor: tokens.colorNeutralStroke2,
        borderBottomColor: tokens.colorNeutralStroke2, borderLeftColor: tokens.colorNeutralStroke2,
        borderTopStyle: 'solid', borderRightStyle: 'solid', borderBottomStyle: 'solid', borderLeftStyle: 'solid',
        borderTopWidth: '1px', borderRightWidth: '1px', borderBottomWidth: '1px', borderLeftWidth: '1px',
        borderRadius: tokens.borderRadiusMedium, backgroundColor: tokens.colorNeutralBackground1,
        color: tokens.colorNeutralForeground1, cursor: 'pointer',
        ':focus-visible': { outlineColor: tokens.colorBrandStroke1, outlineStyle: 'solid', outlineWidth: '2px' },
    },
    selected: { backgroundColor: tokens.colorBrandBackground2, borderLeftColor: tokens.colorBrandStroke1, borderLeftWidth: '3px' },
    row: { display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', flexWrap: 'wrap', gap: tokens.spacingHorizontalS },
    items: { display: 'flex', flexDirection: 'column', gap: tokens.spacingVerticalS, maxHeight: '24rem', overflowY: 'auto' },
    item: { paddingTop: tokens.spacingVerticalS, borderTopColor: tokens.colorNeutralStroke2, borderTopStyle: 'solid', borderTopWidth: '1px', overflowWrap: 'anywhere' },
    muted: { color: tokens.colorNeutralForeground2 },
    warning: {
        backgroundColor: tokens.colorStatusWarningBackground1, color: tokens.colorNeutralForeground1,
        padding: tokens.spacingHorizontalM, borderRadius: tokens.borderRadiusMedium,
    },
    alert: {
        backgroundColor: tokens.colorStatusDangerBackground1, color: tokens.colorNeutralForeground1,
        padding: tokens.spacingHorizontalM, borderRadius: tokens.borderRadiusMedium,
    },
    actions: { display: 'flex', flexWrap: 'wrap', gap: tokens.spacingHorizontalS, alignItems: 'center' },
});

const GeneratedComponent = (props: PageProps) => {
    const { dataApi, pageInput } = props;
    const styles = useStyles();
    const requestedCase = pageInput?.entityName === 'ppcc_disruptioncase' ? pageInput.recordId?.toLowerCase() : undefined;
    const [revision, setRevision] = useState(0);
    const [selected, setSelected] = useState<string | null>(requestedCase ?? null);
    const [search, setSearch] = useState('');
    const [sort, setSort] = useState<'recent' | 'exposure'>('recent');
    const [activeOnly, setActiveOnly] = useState(true);
    const [formError, setFormError] = useState<string | null>(null);
    const [now, setNow] = useState(Date.now);
    const [cases, setCases] = useState<Load<Result<Case>>>(() => {
        const cached = store.cases;
        return { value: cached?.value ?? null, loading: !cached, error: null, unauthorized: false, fetchedAt: cached?.fetchedAt ?? null };
    });
    const [detail, setDetail] = useState<Load<Detail>>(() => {
        const cached = selected ? store.details.get(selected) : undefined;
        return { value: cached?.value ?? null, loading: !!selected && !cached, error: null, unauthorized: false, fetchedAt: cached?.fetchedAt ?? null };
    });
    const ready = !!dataApi;

    useEffect(() => {
        const timer = window.setInterval(() => setNow(Date.now()), 30000);
        return () => window.clearInterval(timer);
    }, []);

    useEffect(() => {
        if (!ready) return;
        let cancelled = false;
        const hit = store.cases;
        if (hit && revision === 0) {
            setCases({ value: hit.value, loading: false, error: null, unauthorized: false, fetchedAt: hit.fetchedAt });
            return;
        }
        setCases({ value: null, loading: true, error: null, unauthorized: false, fetchedAt: null });
        let pending = store.casesPending;
        if (!pending) {
            pending = (async () => {
                const result = await dataApi.queryTable('ppcc_disruptioncase', {
                    select: ['ppcc_disruptioncaseid', 'ppcc_casenumber', 'ppcc_title', 'ppcc_disruptionstatus', 'ppcc_severity',
                        'ppcc_delaydays', 'ppcc_reportedon', 'ppcc_expectedrecoverydate', 'ppcc_impactedordercount',
                        'ppcc_revenueatrisk', 'ppcc_recommendedaction', 'ppcc_recommendationsummary',
                        'ppcc_recommendationconfidence', '_ppcc_supplierid_value', '_ppcc_productid_value'],
                    orderBy: 'ppcc_reportedon desc', pageSize: 100,
                });
                const value = { rows: result.rows as Case[], more: result.hasMoreRows };
                const entry = { value, fetchedAt: Date.now() };
                if (store.casesPending === pending) store.cases = entry;
                return entry;
            })().finally(() => { if (store.casesPending === pending) delete store.casesPending; });
            store.casesPending = pending;
        }
        pending.then((entry) => {
            if (!cancelled) setCases({ value: entry.value, loading: false, error: null, unauthorized: false, fetchedAt: entry.fetchedAt });
        }).catch((error: unknown) => {
            const info = errorInfo(error);
            if (!cancelled) setCases({ value: null, loading: false, error: info.message, unauthorized: info.unauthorized, fetchedAt: null });
        });
        return () => { cancelled = true; };
        // dataApi changes identity every render; readiness and explicit refresh are the stable dependencies.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [ready, revision]);

    useEffect(() => {
        if (!ready || !selected || !cases.value?.rows.some((row) => row.ppcc_disruptioncaseid.toLowerCase() === selected)) {
            setDetail({ value: null, loading: false, error: null, unauthorized: false, fetchedAt: null });
            return;
        }
        let cancelled = false;
        const hit = store.details.get(selected);
        if (hit) {
            setDetail({ value: hit.value, loading: false, error: null, unauthorized: false, fetchedAt: hit.fetchedAt });
            return;
        }
        setDetail({ value: null, loading: true, error: null, unauthorized: false, fetchedAt: null });
        let pending = store.detailsPending.get(selected);
        if (!pending) {
            const caseRow = cases.value.rows.find((row) => row.ppcc_disruptioncaseid.toLowerCase() === selected)!;
            const caseId = selected;
            pending = (async () => {
                const filter = `_ppcc_disruptioncaseid_value eq ${caseId}`;
                const [impactResult, decisionResult, operationResult, evidenceResult, product, supplier] = await Promise.all([
                    dataApi.queryTable('ppcc_impactedorder', {
                        select: ['ppcc_impactedorderid', 'ppcc_impactnumber', 'ppcc_priority', 'ppcc_quantityatrisk',
                            'ppcc_financialexposure', 'ppcc_requiredshipdate', 'ppcc_customerimpactsummary',
                            '_ppcc_orderid_value', '_ppcc_orderdetailid_value', 'ppcc_includedinrecovery'],
                        filter, pageSize: 100,
                    }),
                    dataApi.queryTable('ppcc_recoverydecision', {
                        select: ['ppcc_recoverydecisionid', 'ppcc_decisionnumber', 'ppcc_approvalstate', 'ppcc_requestedaction',
                            'ppcc_iscurrentdecision', 'ppcc_recommendationrationale', 'ppcc_decisionnotes', 'ppcc_decisiontime'],
                        filter, pageSize: 100,
                    }),
                    dataApi.queryTable('ppcc_carrieroperation', {
                        select: ['ppcc_carrieroperationid', 'ppcc_operationnumber', 'ppcc_carrieroperationstate',
                            'ppcc_operationtype', 'ppcc_requestedon', 'ppcc_completedon', 'ppcc_outcomesummary',
                            'ppcc_requestsummary', '_ppcc_recoverydecisionid_value'], filter, pageSize: 100,
                    }),
                    dataApi.queryTable('ppcc_executionevidence', {
                        select: ['ppcc_executionevidenceid', 'ppcc_evidencenumber', 'ppcc_evidencetype', 'ppcc_executionstate',
                            'ppcc_startedon', 'ppcc_completedon', 'ppcc_resultsummary', 'ppcc_communicationdraft'],
                        filter, pageSize: 100,
                    }),
                    idOf(caseRow._ppcc_productid_value)
                        ? dataApi.retrieveRow('nwind_products', { id: idOf(caseRow._ppcc_productid_value)!, select: ['nwind_productsid', 'nwind_productname', 'nwind_productcode'] })
                        : Promise.resolve(null),
                    idOf(caseRow._ppcc_supplierid_value)
                        ? dataApi.retrieveRow('nwind_suppliers', { id: idOf(caseRow._ppcc_supplierid_value)!, select: ['nwind_suppliersid', 'nwind_company'] })
                        : Promise.resolve(null),
                ]);
                const impacts = impactResult.rows as Impact[];
                const operations = operationResult.rows as Operation[];
                const attemptResults = await Promise.all(operations.map((operation) =>
                    dataApi.queryTable('ppcc_carrierattempt', {
                        select: ['ppcc_carrierattemptid', 'ppcc_attemptnumber', 'ppcc_attemptsequence', 'ppcc_executionstate',
                            'ppcc_startedon', 'ppcc_completedon', 'ppcc_responsesummary', 'ppcc_errorcode', 'ppcc_errormessage',
                            '_ppcc_carrieroperationid_value'],
                        filter: `_ppcc_carrieroperationid_value eq ${operation.ppcc_carrieroperationid}`, pageSize: 100,
                    })));
                const orderIds = Array.from(new Set(impacts.map((impact) => idOf(impact._ppcc_orderid_value)).filter((id): id is string => !!id)));
                const lineIds = Array.from(new Set(impacts.map((impact) => idOf(impact._ppcc_orderdetailid_value)).filter((id): id is string => !!id)));
                const [sourceOrders, sourceLines] = await Promise.all([
                    Promise.all(orderIds.map((id) => dataApi.retrieveRow('nwind_orders', {
                        id, select: ['nwind_ordersid', 'nwind_ordernumber', 'nwind_orderdate', 'nwind_shipname', 'nwind_orderstatusid'],
                    }))),
                    Promise.all(lineIds.map((id) => dataApi.retrieveRow('nwind_orderdetails', {
                        id, select: ['nwind_orderdetailsid', 'nwind_primaryname', 'nwind_quantity', 'nwind_unitprice',
                            'nwind_orderdetailstatusid', '_nwind_orderid_value', '_nwind_productid_value'],
                    }))),
                ]);
                const value: Detail = {
                    impacts: { rows: impacts, more: impactResult.hasMoreRows },
                    decisions: { rows: decisionResult.rows as Decision[], more: decisionResult.hasMoreRows },
                    operations: { rows: operations, more: operationResult.hasMoreRows },
                    attempts: { rows: attemptResults.flatMap((result) => result.rows as Attempt[]), more: operationResult.hasMoreRows || attemptResults.some((result) => result.hasMoreRows) },
                    evidence: { rows: evidenceResult.rows as Evidence[], more: evidenceResult.hasMoreRows },
                    orders: new Map(sourceOrders.map((row) => [row.nwind_ordersid.toLowerCase(), row as SourceOrder])),
                    lines: new Map(sourceLines.map((row) => [row.nwind_orderdetailsid.toLowerCase(), row as SourceLine])),
                    product: product as SourceProduct | null, supplier: supplier as SourceSupplier | null,
                };
                const entry = { value, fetchedAt: Date.now() };
                if (store.detailsPending.get(caseId) === pending) store.details.set(caseId, entry);
                return entry;
            })().finally(() => { if (store.detailsPending.get(caseId) === pending) store.detailsPending.delete(caseId); });
            store.detailsPending.set(caseId, pending);
        }
        pending.then((entry) => {
            if (!cancelled) setDetail({ value: entry.value, loading: false, error: null, unauthorized: false, fetchedAt: entry.fetchedAt });
        }).catch((error: unknown) => {
            const info = errorInfo(error);
            if (!cancelled) setDetail({ value: null, loading: false, error: info.message, unauthorized: info.unauthorized, fetchedAt: null });
        });
        return () => { cancelled = true; };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [ready, selected, cases.value, revision]);

    const refresh = () => {
        delete store.cases;
        delete store.casesPending;
        store.details.clear();
        store.detailsPending.clear();
        setFormError(null);
        setRevision((current) => current + 1);
    };
    const openRecord = async (entityName: string, entityId: string) => {
        const xrm = (window as unknown as { Xrm?: { Navigation?: { openForm?: (options: { entityName: string; entityId: string }) => Promise<unknown> } } }).Xrm;
        if (!xrm?.Navigation?.openForm) {
            setFormError('Record forms are unavailable in this host.');
            return;
        }
        try {
            setFormError(null);
            await xrm.Navigation.openForm({ entityName, entityId });
            refresh();
        } catch (error: unknown) {
            setFormError(`Could not open the record form: ${errorInfo(error).message}`);
        }
    };
    const rows = (cases.value?.rows ?? []).filter((row) => {
        if (activeOnly && (row.ppcc_disruptionstatus === 100000006 || row.ppcc_disruptionstatus === 100000007 ||
            row.ppcc_disruptionstatus === 100000008)) return false;
        const needle = search.trim().toLowerCase();
        return !needle || [row.ppcc_title, row.ppcc_casenumber, lookupName(row, '_ppcc_supplierid_value')]
            .some((value) => value?.toLowerCase().includes(needle));
    }).sort((a, b) => sort === 'exposure'
        ? (b.ppcc_revenueatrisk ?? -1) - (a.ppcc_revenueatrisk ?? -1)
        : new Date(b.ppcc_reportedon ?? 0).getTime() - new Date(a.ppcc_reportedon ?? 0).getTime());
    const current = cases.value?.rows.find((row) => row.ppcc_disruptioncaseid.toLowerCase() === selected);
    const details = detail.value;
    const currentDecisions = details?.decisions.rows.filter((row) => row.ppcc_iscurrentdecision === 1) ?? [];
    const latestDecision = currentDecisions.slice().sort((a, b) => new Date(b.ppcc_decisiontime ?? 0).getTime() -
        new Date(a.ppcc_decisiontime ?? 0).getTime())[0];

    return (
        <div className={styles.root}>
            <header className={styles.heading}>
                <div>
                    <Text as="h1" size={800} weight="semibold">Operations control tower</Text>
                    <div className={styles.muted}>Live supplier disruptions and Northwind order context</div>
                </div>
                <Button onClick={refresh}>Refresh live data</Button>
            </header>
            <div className={styles.warning} role="note">
                Approval is not available on this page. A recommendation, case status, task completion or edited form does not authorize recovery.
                A separately secured approval operation is required; until then treat any proposed action as pending here.
                Carrier requests and communications are not shown as successful without recorded outcomes.
            </div>
            {formError && <div role="alert" className={styles.alert}>{formError}</div>}
            {cases.error && <div role="alert" className={styles.alert}>{cases.error}</div>}
            {cases.fetchedAt && now - cases.fetchedAt > TTL && <div role="status" className={styles.warning}>Case list may be stale (last loaded {date(new Date(cases.fetchedAt))}). Refresh for current records.</div>}
            <div className={styles.columns}>
                <section className={`${styles.card} ${styles.sidebar}`} aria-labelledby="missions-heading">
                    <div className={styles.row}><Text id="missions-heading" as="h2" size={500} weight="semibold">Missions</Text><Text>{rows.length} shown</Text></div>
                    <div className={styles.controls}>
                        <Input aria-label="Search cases by number, title or supplier" placeholder="Search missions" value={search} onChange={(_, value) => setSearch(value.value)} />
                        <Button appearance="secondary" onClick={() => setSort(sort === 'recent' ? 'exposure' : 'recent')}>Sort: {sort === 'recent' ? 'recent first' : 'exposure first'}</Button>
                        <Button appearance="secondary" aria-pressed={activeOnly} onClick={() => setActiveOnly(!activeOnly)}>{activeOnly ? 'Active only' : 'All statuses'}</Button>
                    </div>
                    {cases.loading ? <Spinner label="Loading live missions" /> : cases.error ? null :
                        !cases.value?.rows.length ? <Text>No disruption cases are available.</Text> :
                            rows.length === 0 ? <Text>No missions match these filters.</Text> :
                                <div className={styles.list}>
                                    {rows.map((row) => <button key={row.ppcc_disruptioncaseid} type="button"
                                        className={`${styles.mission} ${selected === row.ppcc_disruptioncaseid.toLowerCase() ? styles.selected : ''}`}
                                        aria-pressed={selected === row.ppcc_disruptioncaseid.toLowerCase()}
                                        onClick={() => setSelected(row.ppcc_disruptioncaseid.toLowerCase())}>
                                        <strong>{row.ppcc_casenumber ?? 'Unnumbered case'} · {row.ppcc_title ?? 'Untitled disruption'}</strong>
                                        <span>{choice(row.ppcc_disruptionstatus, statusNames)} · {choice(row.ppcc_severity, severityNames)}</span>
                                        <span>Supplier: {lookupName(row, '_ppcc_supplierid_value')}</span>
                                        <span>Recorded revenue at risk: {amount(row.ppcc_revenueatrisk)} (currency not verified)</span>
                                    </button>)}
                                </div>}
                    {cases.value?.more && <Text role="status" className={styles.warning}>Showing the first 100 missions only; search and sorting apply to loaded records.</Text>}
                </section>
                <main className={styles.main}>
                    {!current ? <section className={styles.card}><Text as="h2" size={500}>{cases.error ? 'Mission review unavailable until access or loading is restored.' : 'Select a mission to review its live records.'}</Text>
                        {requestedCase && !cases.loading && cases.value && <Text>Requested case is not in the first page of available missions.</Text>}
                    </section> : <>
                        <section className={styles.card} aria-labelledby="case-heading">
                            <div className={styles.row}>
                                <Text id="case-heading" as="h2" size={600} weight="semibold">{current.ppcc_title ?? 'Untitled disruption'}</Text>
                                <Button onClick={() => openRecord('ppcc_disruptioncase', current.ppcc_disruptioncaseid)}>Open case form</Button>
                            </div>
                            <Text>{current.ppcc_casenumber ?? 'Unnumbered case'} · {choice(current.ppcc_disruptionstatus, statusNames)} · {choice(current.ppcc_severity, severityNames)}</Text>
                            <Text>Reported: {date(current.ppcc_reportedon)} · Delay: {current.ppcc_delaydays ?? 'Unknown'} days · Expected recovery: {date(current.ppcc_expectedrecoverydate)}</Text>
                            <Text>Supplier: {details?.supplier?.nwind_company ?? lookupName(current, '_ppcc_supplierid_value')} · Product: {details?.product?.nwind_productname ?? lookupName(current, '_ppcc_productid_value')}</Text>
                            <Text>Recorded case exposure: {amount(current.ppcc_revenueatrisk)} (currency not verified) · Recorded impact count: {current.ppcc_impactedordercount ?? 'Not assessed'}</Text>
                            <Text>Recommended action: {choice(current.ppcc_recommendedaction, actionNames)}</Text>
                            <Text>{current.ppcc_recommendationsummary ?? 'No recommendation rationale recorded.'}</Text>
                            <Text className={styles.muted}>Recommendation confidence: {current.ppcc_recommendationconfidence == null ? 'Not recorded' : `${current.ppcc_recommendationconfidence}%`}. Case totals are stored snapshots, not live rollups.</Text>
                        </section>
                        {detail.error && <div role="alert" className={styles.alert}>{detail.error}</div>}
                        {detail.fetchedAt && now - detail.fetchedAt > TTL && <div role="status" className={styles.warning}>Mission details may be stale (last loaded {date(new Date(detail.fetchedAt))}). Refresh before deciding.</div>}
                        {detail.loading && <Spinner label="Loading related Northwind and execution records" />}
                        {details && !detail.loading && <>
                            <section className={styles.card} aria-labelledby="impact-heading">
                                <Text id="impact-heading" as="h2" size={500} weight="semibold">Impacted Northwind order lines</Text>
                                <Text>Recorded line exposure in loaded rows: {details.impacts.rows.some((row) => row.ppcc_financialexposure != null)
                                    ? amount(details.impacts.rows.reduce((sum, row) => sum + (row.ppcc_financialexposure ?? 0), 0))
                                    : 'Not assessed'} (currency not verified; excludes missing values)</Text>
                                {details.impacts.more && <Text role="status" className={styles.warning}>More than 100 impacted lines exist. The displayed sum is partial.</Text>}
                                {!details.impacts.rows.length ? <Text>No impacted order lines recorded for this case.</Text> :
                                    <div className={styles.items}>{details.impacts.rows.map((impact) => {
                                        const order = details.orders.get(idOf(impact._ppcc_orderid_value) ?? '');
                                        const line = details.lines.get(idOf(impact._ppcc_orderdetailid_value) ?? '');
                                        return <div className={styles.item} key={impact.ppcc_impactedorderid}>
                                            <div className={styles.row}><strong>{impact.ppcc_impactnumber ?? 'Unnumbered impact'} · Order {order?.nwind_ordernumber ?? 'Northwind order not linked'}</strong>
                                                <div className={styles.actions}>
                                                    <Button size="small" onClick={() => openRecord('ppcc_impactedorder', impact.ppcc_impactedorderid)}>Open impact form</Button>
                                                    {order && <Button size="small" onClick={() => openRecord('nwind_orders', order.nwind_ordersid)}>Open Northwind order</Button>}
                                                    {line && <Button size="small" onClick={() => openRecord('nwind_orderdetails', line.nwind_orderdetailsid)}>Open Northwind line</Button>}
                                                </div></div>
                                            <Text>Line: {line?.nwind_primaryname ?? 'Northwind line not linked'} · At risk: {impact.ppcc_quantityatrisk ?? 'Unknown'} units · Exposure: {amount(impact.ppcc_financialexposure)} (currency not verified)</Text>
                                            <div className={styles.muted}>Northwind source quantity: {line?.nwind_quantity ?? 'Unavailable'} · Unit price: {amount(line?.nwind_unitprice)} (currency not verified) · Required ship: {date(impact.ppcc_requiredshipdate)}</div>
                                            {impact.ppcc_customerimpactsummary && <div>{impact.ppcc_customerimpactsummary}</div>}
                                        </div>;
                                    })}</div>}
                            </section>
                            <section className={styles.card} aria-labelledby="decision-heading">
                                <Text id="decision-heading" as="h2" size={500} weight="semibold">Recommendation and human decision</Text>
                                <Text>Approval available from this control tower: Pending — no secured approval operation is bound to this page.</Text>
                                {details.decisions.more && <Text role="status" className={styles.warning}>More decision versions exist; current decision may not be in the first 100.</Text>}
                                {!latestDecision ? <Text>No current decision recorded. Approval: Pending on this page; no approval can occur here.</Text> :
                                    <>
                                        <Text>{latestDecision.ppcc_decisionnumber ?? 'Unnumbered proposal'} · Requested: {choice(latestDecision.ppcc_requestedaction, actionNames)}</Text>
                                        <Text>Stored decision state (not authorization from this page): {choice(latestDecision.ppcc_approvalstate, approvalNames)} · Decision time: {date(latestDecision.ppcc_decisiontime)}</Text>
                                        <Text>{latestDecision.ppcc_recommendationrationale ?? 'No decision rationale recorded.'}</Text>
                                        {latestDecision.ppcc_decisionnotes && <Text>Recorded notes: {latestDecision.ppcc_decisionnotes}</Text>}
                                        <Text className={styles.muted}>This is a read-only view of recorded state, not authorization. Do not use direct form edits to approve a recovery.</Text>
                                    </>}
                                {currentDecisions.length > 1 && <Text role="alert" className={styles.warning}>Multiple records are marked current; resolve the conflicting proposals before acting.</Text>}
                            </section>
                            <section className={styles.card} aria-labelledby="carrier-heading">
                                <Text id="carrier-heading" as="h2" size={500} weight="semibold">Carrier operations and attempts</Text>
                                {details.operations.more && <Text className={styles.warning}>Showing the first 100 operations; attempt history may be incomplete.</Text>}
                                {!details.operations.rows.length ? <Text>No carrier operations recorded. No carrier request is implied.</Text> :
                                    <div className={styles.items}>{details.operations.rows.map((operation) =>
                                        <div className={styles.item} key={operation.ppcc_carrieroperationid}>
                                            <div className={styles.row}><strong>{operation.ppcc_operationnumber ?? 'Unnumbered operation'} · {choice(operation.ppcc_operationtype, operationTypes)}</strong>
                                                <Button size="small" onClick={() => openRecord('ppcc_carrieroperation', operation.ppcc_carrieroperationid)}>Open operation form</Button></div>
                                            <Text>Recorded state: {choice(operation.ppcc_carrieroperationstate, operationNames)} · Requested: {date(operation.ppcc_requestedon)} · Completed: {date(operation.ppcc_completedon)}</Text>
                                            <Text>{operation.ppcc_outcomesummary ?? operation.ppcc_requestsummary ?? 'No outcome recorded; do not assume carrier success.'}</Text>
                                            {details.attempts.rows.filter((attempt) => idOf(attempt._ppcc_carrieroperationid_value) === operation.ppcc_carrieroperationid.toLowerCase())
                                                .sort((a, b) => (a.ppcc_attemptsequence ?? 0) - (b.ppcc_attemptsequence ?? 0)).map((attempt) =>
                                                    <div className={styles.item} key={attempt.ppcc_carrierattemptid}>
                                                        <div className={styles.row}><Text>Attempt {attempt.ppcc_attemptsequence ?? '?'} · {choice(attempt.ppcc_executionstate, executionNames)}</Text>
                                                            <Button size="small" onClick={() => openRecord('ppcc_carrierattempt', attempt.ppcc_carrierattemptid)}>Open attempt form</Button></div>
                                                        <Text>Started: {date(attempt.ppcc_startedon)} · Completed: {date(attempt.ppcc_completedon)}</Text>
                                                        <Text>{attempt.ppcc_responsesummary ?? attempt.ppcc_errormessage ?? 'No response recorded.'}</Text>
                                                    </div>)}
                                        </div>)}</div>}
                                {details.attempts.more && <Text className={styles.warning}>Some attempt history is not loaded; do not infer a final outcome.</Text>}
                            </section>
                            <section className={styles.card} aria-labelledby="evidence-heading">
                                <Text id="evidence-heading" as="h2" size={500} weight="semibold">Execution evidence and communications</Text>
                                {details.evidence.more && <Text className={styles.warning}>Showing only the first 100 evidence records.</Text>}
                                {!details.evidence.rows.length ? <Text>No execution evidence recorded. No work or communication is confirmed.</Text> :
                                    <div className={styles.items}>{details.evidence.rows.map((entry) =>
                                        <div className={styles.item} key={entry.ppcc_executionevidenceid}>
                                            <div className={styles.row}><strong>{entry.ppcc_evidencenumber ?? 'Unnumbered evidence'} · {choice(entry.ppcc_evidencetype, evidenceNames)}</strong>
                                                <Button size="small" onClick={() => openRecord('ppcc_executionevidence', entry.ppcc_executionevidenceid)}>Open evidence form</Button></div>
                                            <Text>Recorded state: {choice(entry.ppcc_executionstate, executionNames)} · Completed: {date(entry.ppcc_completedon)}</Text>
                                            <Text>{entry.ppcc_resultsummary ?? 'No verified result recorded.'}</Text>
                                            {entry.ppcc_communicationdraft && <Text className={styles.muted}>Communication draft exists; this does not confirm it was sent.</Text>}
                                        </div>)}</div>}
                            </section>
                        </>}
                    </>}
                </main>
            </div>
        </div>
    );
};

export default GeneratedComponent;


